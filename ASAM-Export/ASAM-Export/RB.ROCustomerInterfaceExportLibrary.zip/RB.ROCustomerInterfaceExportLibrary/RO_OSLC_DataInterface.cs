﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace RB.ROCustomerInterfaceExportLibrary
{
    public class RO_OSLC_DataInterface : RODataInterface
    {
        private string sExchangeFormat;
        private AsyncLogger async_objlogger;
        private Logger obj_ologger;
        public string recordID = string.Empty;
        

        public RO_OSLC_DataInterface(string p_System, string p_sExchangeFormat, string RecordID, AsyncLogger async_ologger = null)
            : base(p_System, p_sExchangeFormat, RecordID, async_ologger)
        {
            sExchangeFormat = p_sExchangeFormat;
            async_objlogger = async_ologger;
            recordID = RecordID;

        }

        public XElement FetchAttachments(string recordID, string dbid, string url, AsyncLogger async_objlogger)
        {
            XElement attachmentsRoot = new XElement("Attachmentss");
            using (HttpClient client = new HttpClient())
            {
                // Set Authorization header
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", "RkZNM0ZFOkRvTm90VXNlNFlvdXJUZXN0");

                // Set Accept header
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("*/*"));

                try
                {
                    HttpResponseMessage response = client.GetAsync(url).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        string atomXmlString = response.Content.ReadAsStringAsync().Result;

                        XNamespace atomNs = "http://www.w3.org/2005/Atom";
                        XNamespace cqNs = "http://www.ibm.com/xmlns/prod/rational/clearquest/1.0/";

                        XDocument inputDoc = XDocument.Parse(atomXmlString);
                       

                        var entries = inputDoc.Descendants(atomNs + "entry").ToList();

                        foreach (var entry in entries)
                        {
                            var filename = entry
                                .Element(atomNs + "content")?
                                .Element(cqNs + "attachment")?
                                .Element(cqNs + "filename")?.Value;

                            if (!string.IsNullOrEmpty(filename))
                            {
                                XElement attachmentElem = new XElement("Attachments",
                                    new XAttribute("recordtype", "Attachments"),
                                    new XAttribute("dbid", dbid),
                                    new XElement("entity_dbid", dbid),
                                    new XElement("filename", filename),
                                    new XElement("type", "")
                                );

                                attachmentsRoot.Add(attachmentElem);
                            }
                        }                       

                    }
                    else
                    {                       
                        string errorContent = response.Content.ReadAsStringAsync().Result;                        
                    }
                }
                catch (Exception ex)
                {
                    
                }
            }

            return attachmentsRoot;
        }
        

        public string InvokeUrl4ReadOperation(string recordID, string sUrlToInvoke, AsyncLogger async_objlogger)
        {
            async_objlogger.LogInfoAsync(recordID, "ClearQuest::InvokeURL : Starts with URL:\n" + sUrlToInvoke);
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    // Create the Basic Authentication header
                    var byteArray = Encoding.ASCII.GetBytes($"{CQUser}:{CQPasword}");
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                    string sRequesterInfo = "toolname=" + CQToolName + ";toolversion=" + CQToolVersion + ";user=" + "bt9rsi";

                    // Set request headers
                    client.DefaultRequestHeaders.Add("OSLC-Core-Version", "2.0");
                    client.DefaultRequestHeaders.Add("x-requester", sRequesterInfo);

                    // Send the GET request synchronously
                    HttpResponseMessage response = client.GetAsync(sUrlToInvoke).Result;

                    // Ensure the response status is successful
                    response.EnsureSuccessStatusCode();

                    async_objlogger.LogInfoAsync(recordID, "ClearQuest::InvokeURL : ends");

                    // Read and return the response content
                    return response.Content.ReadAsStringAsync().Result;
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions and propagate them
                throw new Exception($"Error while invoking URL: {ex.Message}", ex);
            }
        }


        public string InvokeUrl4UpdateOperation(string recordID, string sUrlToInvoke, XmlDocument XIMF, string recordType, AsyncLogger async_objlogger)
        {
            async_objlogger.LogInfoAsync(recordID, "ClearQuest::InvokeURL : Starts with URL:\n" + sUrlToInvoke);
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    // Create the Basic Authentication header
                    var byteArray = Encoding.ASCII.GetBytes($"{CQUser}:{CQPasword}");
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                    string sRequesterInfo = "toolname=" + CQToolName + ";toolversion=" + CQToolVersion + ";user=" + "bt9rsi";

                    // Set request headers
                    client.DefaultRequestHeaders.Add("OSLC-Core-Version", "2.0");
                    client.DefaultRequestHeaders.Add("x-requester", sRequesterInfo);

                    string xmlBody = GenerateBody(XIMF, sUrlToInvoke, recordType);

                    HttpContent content = new StringContent(xmlBody, Encoding.UTF8, "application/xml");

                    // Send the PUT request synchronously
                    HttpResponseMessage response = client.PutAsync(sUrlToInvoke, content).Result;

                    // Ensure the response status is successful
                    response.EnsureSuccessStatusCode();

                    async_objlogger.LogInfoAsync(recordID, response.Content.ReadAsStringAsync().Result);

                    async_objlogger.LogInfoAsync(recordID, "ClearQuest::InvokeURL : ends");

                    // Read and return the response content
                    return response.Content.ReadAsStringAsync().Result;
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions and propagate them
                throw new Exception($"Error while invoking URL: {ex.Message}", ex);
                async_objlogger.LogExceptionAsync(recordId, ex);
                async_objlogger.LogInfoAsync(recordID, "RQ1 Updation Failed due to an exception.");
            }
        }

        public string GenerateBody(XmlDocument XIMF, string url, string recordType)
        {
            string xmlbody = string.Empty;

            Match match = Regex.Match(url, @"^([^?]+)");
            url = match.Success ? match.Groups[1].Value : string.Empty;
            


            try
            {
                if (recordType.ToUpper() == "ISSUE")
                {
                    XmlNamespaceManager nsManager = new XmlNamespaceManager(XIMF.NameTable);
                    nsManager.AddNamespace("ns0", "http://RB.ROCustomerInterfaceExport.Schemas.Export_IMF.Export_IMF");

                    XmlNode issueNode = XIMF.SelectSingleNode("//ISSUE", nsManager);

                    if (issueNode != null)
                    {
                        StringBuilder rdfXml = new StringBuilder();
                        rdfXml.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>");
                        rdfXml.AppendLine("<rdf:RDF ");
                        rdfXml.AppendLine("         xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"");
                        rdfXml.AppendLine("         xmlns:oslc=\"http://open-services.net/ns/core#\"");
                        rdfXml.AppendLine("         xmlns:dcterms=\"http://purl.org/dc/terms/\"");
                        rdfXml.AppendLine("         xmlns:cq=\"http://www.ibm.com/xmlns/prod/rational/clearquest/1.0/\"");
                        rdfXml.AppendLine("         xmlns:oslc_cm=\"http://open-services.net/ns/cm#\"");
                        rdfXml.AppendLine("         xmlns:rdfs=\"http://www.w3.org/2000/01/rdf-schema#\">");
                        rdfXml.AppendLine("    <oslc_cm:ChangeRequest rdf:about=\"https://your-url-here\">");
                        rdfXml.AppendLine("        <dcterms:type>Issue</dcterms:type>");
                        rdfXml.AppendLine("        <cq:OperationMode rdf:ID=\"OperationMode\">ASAM-EXPORT</cq:OperationMode>");
                        rdfXml.AppendLine("        <cq:OperationContext rdf:ID=\"OperationContext\">EDES</cq:OperationContext>");

                        // Dynamically add all ISSUE child elements
                        foreach (XmlNode child in issueNode.ChildNodes)
                        {
                            string tagName = child.Name;
                            string tagValue = child.InnerText.Trim();

                            // Only add non-empty values to the RDF output
                            if (!string.IsNullOrEmpty(tagValue))
                            {
                                rdfXml.AppendLine($"        <cq:{tagName} rdf:ID=\"{tagName}\">{tagValue}</cq:{tagName}>");
                            }
                        }

                        rdfXml.AppendLine("    </oslc_cm:ChangeRequest>");
                        rdfXml.AppendLine("    <rdf:Statement rdf:about=\"#OperationMode\">");
                        rdfXml.AppendLine("        <cq:fieldOrder>79</cq:fieldOrder>");
                        rdfXml.AppendLine("    </rdf:Statement>");
                        rdfXml.AppendLine("    <rdf:Statement rdf:about=\"#OperationContext\">");
                        rdfXml.AppendLine("        <cq:fieldOrder>78</cq:fieldOrder>");
                        rdfXml.AppendLine("    </rdf:Statement>");
                        rdfXml.AppendLine("</rdf:RDF>");

                        xmlbody = rdfXml.ToString();

                        xmlbody = xmlbody.Replace("https://your-url-here", url);
                    }

                }


            }

            catch (Exception ex)
            {

            }

            return xmlbody;

        }

        public string InvokeUrl4UpdateXport(string recordID, string sUrlToInvoke, string xprotLog, string xprotStatus, AsyncLogger async_objlogger = null)
        {
           
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    // Create the Basic Authentication header
                    var byteArray = Encoding.ASCII.GetBytes($"{CQUser}:{CQPasword}");
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                    string sRequesterInfo = "toolname=" + CQToolName + ";toolversion=" + CQToolVersion + ";user=" + "bt9rsi";

                    // Set request headers
                    client.DefaultRequestHeaders.Add("OSLC-Core-Version", "2.0");
                    client.DefaultRequestHeaders.Add("x-requester", sRequesterInfo);

                    string xmlBody = GlobalConstants.QueryBody.XprotBody;
                    string cleanedUrl = sUrlToInvoke.Split('?')[0];

                    xmlBody = xmlBody.Replace("XprotLog", xprotLog);
                    xmlBody = xmlBody.Replace("XprotStatus", xprotStatus);
                    xmlBody = xmlBody.Replace("url", cleanedUrl);

                    

                    HttpContent content = new StringContent(xmlBody, Encoding.UTF8, "application/xml");

                    // Send the PUT request synchronously
                    HttpResponseMessage response = client.PutAsync(sUrlToInvoke, content).Result;

                    // Ensure the response status is successful
                    response.EnsureSuccessStatusCode();

                    // Read and return the response content
                    return response.Content.ReadAsStringAsync().Result;
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions and propagate them
                throw new Exception($"Error while invoking URL: {ex.Message}", ex);
                
            }
        }

        public string CreateQuery(string recordType, string recordID,  string queryname, string queryparam, AsyncLogger objLogger = null)
        {
            if(objLogger != null)
            {
                objLogger.LogInfoAsync(recordID, "CreateQuery Started : ");

                objLogger.LogInfoAsync(recordID, "CreateQuery For : " + queryname);
            }
            

            string oQuery = string.Empty;
            string baseUrl = string.Empty;
            string type = string.Empty;
            string attributeString = string.Empty;
            string whereString = string.Empty;
            try
            {
                if (recordType.ToUpper() == "ISSUE")
                {
                    XElement xQueryNode = InterfaceConfigFile.Descendants("QUERY")
                            .FirstOrDefault(q => (string)q.Element("NAME") == queryname);

                    if (xQueryNode == null)
                    {
                        throw new Exception($"Query with name {queryname} not found.");
                    }

                    else
                    {
                        if (objLogger != null)
                        {
                            objLogger.LogInfoAsync(recordID, "CreateQuery  : " + "Query Node found");
                        }
                            

                        baseUrl = xQueryNode.Element("baseurl").Value;

                        type = xQueryNode.Element("type").Value;

                        if (type == "READ")
                        {
                            // Get attributes and construct comma-separated list
                            var attributes = xQueryNode.Element("attributes")?.Elements("attribute").Select(attr => Uri.EscapeDataString(attr.Value)).ToList();

                            if (attributes == null || !attributes.Any())
                            {
                                baseUrl = baseUrl.Replace("recorddbid", queryparam);
                                oQuery = baseUrl;
                            }
                            else
                            {
                                // Join attributes with a comma separator
                                attributeString = string.Join(",", attributes);

                                attributeString = "oslc.properties=" + attributeString;

                                // construct where clause
                                whereString = "oslc.where=" + xQueryNode.Element("where").Value;

                                whereString = whereString.Replace("RQ1id", queryparam);

                                oQuery = baseUrl + "&" + whereString + "&" + attributeString;
                            }
                            

                            if (objLogger != null)
                            {
                                objLogger.LogInfoAsync(recordID, "CreateQuery query generated : " + oQuery);
                            }
                        }

                        else if (type == "UPDATE")
                        {
                            // Get attributes and construct comma-separated list
                            var attributes = xQueryNode.Element("attributes")?.Elements("attribute").Select(attr => Uri.EscapeDataString(attr.Value)).ToList();

                            if (attributes == null || !attributes.Any())
                            {
                                throw new Exception($"No attributes found for query {queryname}.");
                            }

                            else
                            {
                                attributeString = string.Join(",", attributes);

                                baseUrl = baseUrl.Replace("recorddbid", queryparam);
                                baseUrl = baseUrl.Replace("%3A", ":");

                                attributeString = "oslc.properties=" + attributeString;

                                oQuery = baseUrl + "?rcm.action=modify&" + attributeString;
                                if (objLogger != null)
                                {
                                    objLogger.LogInfoAsync(recordID, "CreateQuery query generated : " + oQuery);
                                }
                            }
                            
                        }



                    }
                }

                else if (recordType.ToUpper() == "XPROT")
                {

                    XElement xQueryNode = InterfaceConfigFile.Descendants("QUERY")
                            .FirstOrDefault(q => (string)q.Element("NAME") == queryname);

                    if (xQueryNode == null)
                    {
                        throw new Exception($"Query with name {queryname} not found.");
                    }

                    else
                    {
                        

                        baseUrl = xQueryNode.Element("baseurl").Value;

                        type = xQueryNode.Element("type").Value;

                        

                        if (type == "UPDATE")
                        {
                            // Get attributes and construct comma-separated list
                            var attributes = xQueryNode.Element("attributes")?.Elements("attribute").Select(attr => Uri.EscapeDataString(attr.Value)).ToList();

                            if (attributes == null || !attributes.Any())
                            {
                                throw new Exception($"No attributes found for query {queryname}.");
                            }

                            attributeString = string.Join(",", attributes);

                            baseUrl = baseUrl.Replace("recorddbid", queryparam);
                            baseUrl = baseUrl.Replace("%3A", ":");

                            attributeString = "oslc.properties=" + attributeString;

                            oQuery = baseUrl + "?rcm.action=modify&" + attributeString;
                        }

                    }
                }
            }

            catch (Exception ex)
            {
                if (objLogger != null)
                {
                    objLogger.LogInfoAsync(recordID, "CreateQuery Execution failed with the exception : " + ex.Message);
                }
            }

            
            return oQuery;
        }

        
        
    }
}
