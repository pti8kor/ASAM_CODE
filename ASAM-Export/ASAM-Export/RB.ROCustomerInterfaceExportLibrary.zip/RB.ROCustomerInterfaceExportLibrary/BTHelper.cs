﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml.Xsl;
using System.Reflection;
using Saxon.Api;

namespace RB.ROCustomerInterfaceExportLibrary
{
    [Serializable]
    public class BTHelper
    {
        #region Logger

        public string GetConfigPathForLogger(string sExchangeFormat, string sXPROT)
        {
            string configPath = Utilities.LoadItemFromBizTalkAppConfig(GlobalConstants.LOGGER_KEY);
            string strdatetime = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            strdatetime = strdatetime.Replace('/', '.'); // '/' not acc in file name
            strdatetime = strdatetime.Replace(':', '.'); //:not acc in file name
            string sPath = strdatetime + "_" + sExchangeFormat + "_" + sXPROT + ".txt";
            configPath = configPath + "\\" + sXPROT+ "\\" + sPath;
            return configPath;
        }

        public string GetConfigPathForFolderCreation(string sExchangeFormat, string sXPROT)
        {
            string configPath = Utilities.LoadItemFromBizTalkAppConfig(GlobalConstants.LOGGER_KEY);
            string strdatetime = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            strdatetime = strdatetime.Replace('/', '.'); // '/' not acc in file name
            strdatetime = strdatetime.Replace(':', '.'); //:not acc in file name
            string sPath = sXPROT;
            configPath = configPath + sPath;
            return configPath;
        }

        public string GetConfigpathForAsyncLogger()
        {
            string configPath = string.Empty;

            return configPath = Utilities.LoadItemFromBizTalkAppConfig(GlobalConstants.LOGGER_KEY);
        }


        public void SetLoggingMode(string sExchangeFormat, Logger objlogger)
        {

            try
            {
                string strConfigFilePath = Utilities.LoadItemFromBizTalkAppConfig(GlobalConstants.INTERFACE_CONFIG_PATTERN);
                ROConfigurationManager rConfigMgr = new ROConfigurationManager(strConfigFilePath, objlogger);
                XDocument l_oConfig = rConfigMgr.LoadConfigurationXML();

                string sLogLevel = string.Empty;

                foreach (XElement xe in l_oConfig.Root.Element(ConfigurationFileTags.INTERFACE_SETTINGS).Element("LOGGER_SETTINGS").Elements("LOGGINGLEVEL").Where(e => e.Attribute("ENABLE").Value == "TRUE"))
                {
                    sLogLevel = xe.Attribute("LEVEL").Value;
                }

                objlogger.LogInfo("Setting Log Level value", GlobalConstants.LOGGERLEVEL1);
                switch (sLogLevel)
                {
                    case "1":
                        objlogger.iLogLevel = GlobalConstants.LOGGERLEVEL1;
                        break;

                    case "2":
                        objlogger.iLogLevel = GlobalConstants.LOGGERLEVEL2;
                        break;

                    case "3":
                        objlogger.iLogLevel = GlobalConstants.LOGGERLEVEL3;
                        break;

                    default:
                        objlogger.LogException("Please enable atleast one Logger level");
                        break;
                }
                objlogger.LogInfo("Log Level Value: " + objlogger.iLogLevel, GlobalConstants.LOGGERLEVEL1);


            }
            catch (Exception ex)
            {
                objlogger.LogException(ex);
            }

        }


        #endregion
       

        #region Updation of RQ1 Records
        public bool UpdateRecords(XmlDocument XIMF, string recordData, string xprotID, string p_system, string sExchangeFormat, AsyncLogger async_objLogger)
        {
            string RecordID = string.Empty;
            string RecordType = string.Empty;
            string queryParam = string.Empty;

            bool result = false;

            XmlDocument xDoc = new XmlDocument();

            XElement root = null;

            if (!string.IsNullOrEmpty(recordData))
            {
                var recordDetails = recordData.Split(':');
                RecordID = recordDetails[0].Trim();
                RecordType = recordDetails[1].Trim();
            }

            async_objLogger.LogInfoAsync(RecordID, "UpdateRecords Started : ");

            try
            {
                if (RecordType.ToUpper() == "ISSUE")
                {
                    // Fetch dbid from IMF for updating Issue
                    XDocument xIssuedoc = null;
                    using (var nodeReader = new XmlNodeReader(XIMF))
                    {
                        nodeReader.MoveToContent();
                        xIssuedoc = XDocument.Load(nodeReader);
                    }

                    string dbid = string.Empty;
                    dbid = xIssuedoc.Root.Element(IMFFileTags.Issue).Attribute("dbid").Value;

                    //execute Issue entry point methods
                    async_objLogger.LogInfoAsync(RecordID, "Started Executing Update Issue Entry Point Methods: ");

                    RO_OSLC_DataInterface obj = new RO_OSLC_DataInterface(p_system, sExchangeFormat, RecordID, async_objLogger);


                    queryParam = dbid;
                    var queryurl = obj.CreateQuery(RecordType, RecordID, GlobalConstants.QueryMethods.UpdateIssue, queryParam, async_objLogger);

                    async_objLogger.LogInfoAsync(RecordID, "Query Created Succesfully.");

                    var queryResult = obj.InvokeUrl4UpdateOperation(RecordID, queryurl, XIMF, RecordType, async_objLogger);

                    async_objLogger.LogInfoAsync(RecordID, queryResult);
                    async_objLogger.LogInfoAsync(RecordID, "Record Updated Succesfully.");

                    result = true;
                }
            }

            catch(Exception ex)
            {
                async_objLogger.LogInfoAsync(RecordID, "Record Updated Failed.");
                async_objLogger.LogInfoAsync(RecordID, ex.Message);
            }

            return result;
            
        }

        public string UpdateLifeToken(string recordData, string sXprotID, string LifeToken4Files,bool isUpdated, AsyncLogger async_objLogger)
        {
            
            string RecordID = string.Empty;
            string RecordType = string.Empty;
            

            string updatedLifeToken = string.Empty;

            try
            {
                if (!string.IsNullOrEmpty(recordData))
                {
                    var recordDetails = recordData.Split(':');
                    RecordID = recordDetails[0].Trim();
                    RecordType = recordDetails[1].Trim();
                }
                string pattern = string.Empty;
                string replacement = string.Empty;


                if (isUpdated)
                {
                    pattern = $@"({RecordID}: Issue::)[^|]+";
                    replacement = $"${{1}}{"Success"} - {"Export Successful"}";

                    
                }

                else
                {
                    pattern = $@"({RecordID}: Issue::)[^|]+";
                    replacement = $"${{1}}{"Failure"} - {"Export Failed"}";
                }

                updatedLifeToken = Regex.Replace(LifeToken4Files, pattern, replacement);

                async_objLogger.LogInfoAsync(RecordID, updatedLifeToken);



            }

            catch (Exception ex)
            {

            }  

            return updatedLifeToken;
        }

        public string UpdateExchangeProtocol(string xprotID, string p_system, string interfaceName, string lifeToken4Files, string xprotStatus)
        {
            string result = String.Empty;

            string queryParam = xprotID;

            RO_OSLC_DataInterface obj = new RO_OSLC_DataInterface(p_system, interfaceName, xprotID);

            var queryurl = obj.CreateQuery("xprot", xprotID, GlobalConstants.QueryMethods.UpdateXprot, queryParam);

            var queryResult = obj.InvokeUrl4UpdateXport(xprotID, queryurl, lifeToken4Files, xprotStatus);

            return result;
        }

        #endregion

        #region Validate & Execute Orchestration's methods




        /// <summary>
        /// Create ASAM file
        /// </summary>
        /// <param name="RQ1Extract_data"></param>
        /// <param name="XprotID"></param>
        /// <param name="sExchangeFormat"></param>
        /// <param name="async_objLogger"></param>
        /// <returns></returns>

        public string CreateASAMFile(XmlDocument RQ1Extract_data, string XprotID, string sExchangeFormat, AsyncLogger async_objLogger)
        {
            string transformedXml = string.Empty;

            string folderPath = "D:\\ASAM-IF-EXPORT\\Export\\030 - ASAMFiles\\" + XprotID + "\\";
            Task.Run(() =>
            {
                try
                {
                    
                    // Load the XSLT from file path
                    string xsltPath = XsltConfig.ASAM_AUDI300_SPECIFIED;

                    // Create Saxon processor and compiler
                    Processor processor = new Processor();
                    XsltCompiler compiler = processor.NewXsltCompiler();

                    // Compile the XSLT from file path
                    XsltExecutable executable = compiler.Compile(new Uri(xsltPath));

                    // Load the input XML from XmlDocument into a stream
                    MemoryStream inputStream = new MemoryStream(Encoding.UTF8.GetBytes(RQ1Extract_data.OuterXml));

                    // Prepare input
                    XdmNode input = processor.NewDocumentBuilder().Build(XmlReader.Create(inputStream));

                    // Load the transformer
                    XsltTransformer transformer = executable.Load();
                    transformer.InitialContextNode = input;

                    // Prepare the output writer
                    StringWriter outputWriter = new StringWriter();
                    Serializer serializer = processor.NewSerializer(outputWriter);
                    serializer.SetOutputProperty(Serializer.INDENT, "yes");

                    // Run the transformation
                    transformer.Run(serializer);

                    // Get transformed result
                    transformedXml = outputWriter.ToString();


                    //save the tansformed ASAM file

                    // Ensure folder exists
                    Directory.CreateDirectory(folderPath);

                    // Generate a unique ASAM file name
                    string fileName = ExtractFileNameFromXml(transformedXml);

                    string fullPath = Path.Combine(folderPath, fileName);

                    File.WriteAllText(fullPath, transformedXml);

                }
                catch (Exception ex)
                {
                    // You can log this using your async logger if needed

                    throw;
                }
            });
            

            return transformedXml;
        }

        public static string ExtractFileNameFromXml(string xmlContent)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xmlContent);

            // Add the namespace manager
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
            nsmgr.AddNamespace("iss", "http://www.asam.net/schemas/issue/issue300");

            // Select the top-level SHORT-NAME
            XmlNode shortNameNode = doc.SelectSingleNode("/iss:MSR-ISSUE/iss:SHORT-NAME", nsmgr);

            return shortNameNode?.InnerText ?? "DefaultFileName.xml";
        }

        /// <summary>
        /// Create Rq1 data extract file
        /// </summary>
        /// <param name="recordData"></param>
        /// <param name="xprotID"></param>
        /// <param name="p_system"></param>
        /// <param name="sExchangeFormat"></param>
        /// <param name="async_objLogger"></param>
        /// <returns></returns>
        public XmlDocument CreateRQ1DataExtractFile(string recordData, string xprotID, string p_system, string sExchangeFormat, AsyncLogger async_objLogger)
        {

            string RecordID = string.Empty;
            string RecordType = string.Empty;
            string queryParam = string.Empty;

            XmlDocument xDoc = new XmlDocument();

            XElement root = null;

            if (!string.IsNullOrEmpty(recordData))
            {
                var recordDetails = recordData.Split(':');
                RecordID = recordDetails[0].Trim();
                RecordType = recordDetails[1].Trim();
            }

            try
            {
                async_objLogger.LogInfoAsync(RecordID, "CreateRQ1DataExtractFile Started : ");

                string data = string.Empty;

                if (RecordType.ToUpper() == "ISSUE")
                {
                    // Attribute templates for different record types
                    var recordTemplates = new Dictionary<string, List<string>>
                {
                    { "users", new List<string> {   "dbid",
                                                    "email",
                                                    "fullname",
                                                    "login_name",
                                                    "phone" } },

                    { "Contact", new List<string> { "dbid",
                                                    "eMail",
                                                    "Department",
                                                    "FirstName",
                                                    "LastName",
                                                    "PhoneNumbers" } },

                    { "Issue", new List<string> {  "dbid",
                                                    "id",
                                                    "Assignee",
                                                    "Attachments",
                                                    "CommercialAssignee",
                                                    "Domain",
                                                    "ExternalAssignee",
                                                    "ExternalComment",
                                                    "ExternalConversation",
                                                    "ExternalExchangedAttach",
                                                    "ExternalExchangeWorkflow",
                                                    "ExternalHistory",
                                                    "ExternalNextState",
                                                    "ExternalOrganisation",
                                                    "ExternalState_Parallel1",
                                                    "ExternalSubmitter",
                                                    "ExternalTitle",
                                                    "External_ID",
                                                    "hasAttachmentMappings",
                                                    "hasCommercialData",
                                                    "OEMProposalAdopted",
                                                    "Tags",
                                                    "Type"  } },

                    { "Release", new List<string> { "version",
                                                    "release_date",
                                                    "notes" } },

                    { "IssueReleaseMap", new List<string> { "dbid",
                                                            "id",
                                                            "Assignee",
                                                            "ExternalComment",
                                                            "ExternalConversation",
                                                            "ExternalNextState",
                                                            "External_ID","hasMappedIssue","hasMappedRelease","MappingToDerivatives","isPilot"} },

                    {"AttachmentMapping", new List<string> { "dbid",
                                                             "Attribute",
                                                             "ExportState",
                                                             "Eng_Attachment",
                                                             "Sales_Attachment"} },

                    {"Attachments", new List<string> {       "entity_dbid",
                                                             "filename",
                                                             "type"} },

                    {"Commercial", new List<string> {       "dbid",
                                                             "CommercialAmount",
                                                             "CommercialAmountDetails",
                                                             "CommercialAmountUnit",
                                                             "CommercialAttachments",
                                                             "CommercialComment",
                                                             "CommercialConversation",
                                                             "CommercialTags"} },
                };

                    //execute Issue entry point methods
                    async_objLogger.LogInfoAsync(RecordID, "Started Executing Issue Entry Point Methods: ");

                    RO_OSLC_DataInterface obj = new RO_OSLC_DataInterface(p_system, sExchangeFormat,RecordID, async_objLogger);

                    //execute getIssueById
                    queryParam = RecordID;
                    var queryurl = obj.CreateQuery(RecordType, RecordID, GlobalConstants.QueryMethods.getIssueByIdForIssueEntrypoint, queryParam, async_objLogger);

                    var queryResult = obj.InvokeUrl4ReadOperation(RecordID, queryurl, async_objLogger);


                    // Load the input XML
                    XDocument inputXml = XDocument.Parse(queryResult);

                    async_objLogger.LogInfoAsync(RecordID, "method ProcessRecordsDynamically started : ");

                    // Process records dynamically and generate  XML Element
                    root = ProcessRecordsDynamically(inputXml, recordTemplates);


                    //Converting Xelement into XmlDocument 
                    using (var reader = root.CreateReader())
                    {
                        xDoc.Load(reader);
                    }

                    xDoc = FormatXmlDocument(xDoc);

                    //Fetch DBId of the Record
                    string dbid = ExtractDbid(xDoc.InnerXml.ToString(), RecordType);

                    //fetching attahments
                    queryurl = obj.CreateQuery(RecordType, RecordID, GlobalConstants.QueryMethods.getIssueAttachments, dbid, async_objLogger);
                    XElement attachmentsElement = obj.FetchAttachments(RecordID, dbid, queryurl, async_objLogger);

                    // Convert XElement to XmlNode
                    XmlDocument tempDoc = new XmlDocument();
                    tempDoc.LoadXml(attachmentsElement.ToString());
                    XmlNode importedNode = xDoc.ImportNode(tempDoc.DocumentElement, true);

                    // Append to main XmlDocument
                    xDoc.DocumentElement.AppendChild(importedNode);

                }
            }

            catch (Exception ex)
            {
                async_objLogger.LogExceptionAsync(RecordID, ex);
            }

            return xDoc;

        }

        public static string ExtractDbid(string xmlString, string tagName)
        {
            XDocument doc = XDocument.Parse(xmlString);

            // Dynamically find elements by tag name
            var dbid = doc.Descendants(tagName)
                      .FirstOrDefault()?.Attribute("dbid")?.Value;

            return dbid;
        }

        /// <summary>
        /// This help process the data dynamically that has been fetched in CreateRQ1Etract method
        /// </summary>
        /// <param name="inputXml"></param>
        /// <param name="recordTemplates"></param>
        /// <returns></returns>
        static XElement ProcessRecordsDynamically(XDocument inputXml, Dictionary<string, List<string>> recordTemplates)
        {
            XElement root = new XElement("RQ1_EXTRACT", new XAttribute("CreationDate", DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss")));

            XNamespace oslcCmNs = "http://open-services.net/ns/cm#";
            XNamespace dctermsNs = "http://purl.org/dc/terms/";
            XNamespace cqNs = "http://www.ibm.com/xmlns/prod/rational/clearquest/1.0/";

            foreach (var recordType in recordTemplates.Keys)
            {
                var records = inputXml.Descendants(oslcCmNs + "ChangeRequest")
                              .Where(cr => cr.Element(dctermsNs + "type")?.Value == recordType)
                               .Select(cr => new
                               {
                                   RecordType = cr.Element(dctermsNs + "type")?.Value ?? "Unknown",
                                   Attributes = recordTemplates[recordType].ToDictionary(
                                        attr => attr,
                                        attr =>
                                        {
                                            var element = cr.Element(cqNs + attr);

                                            if (recordType == "Issue")
                                            {
                                                if (attr.Contains("Assignee") && element != null)
                                                {
                                                    // Special handling for Assignee to get only dbid
                                                    var changeRequestElement = element.Element(oslcCmNs + "ChangeRequest");
                                                    var dbidElement = changeRequestElement?.Element(cqNs + "dbid");
                                                    return dbidElement != null ? dbidElement.Value : "";
                                                }

                                                if (attr.Contains("hasCommercialData") && element != null)
                                                {
                                                    // Special handling for hasCommercialData to get only dbid
                                                    var changeRequestElement = element.Element(oslcCmNs + "ChangeRequest");
                                                    var dbidElement = changeRequestElement?.Element(cqNs + "dbid");
                                                    return dbidElement != null ? dbidElement.Value : "";
                                                }

                                                if (attr.Contains("hasAttachmentMappings") && element != null)
                                                {
                                                    // Special handling for hasAttachmentMappings to get only dbid
                                                    var changeRequestElement = element.Element(oslcCmNs + "ChangeRequest");
                                                    var dbidElement = changeRequestElement?.Element(cqNs + "dbid");
                                                    return dbidElement != null ? dbidElement.Value : "";
                                                }

                                                if (attr.Contains("Submitter") && element != null)
                                                {
                                                    // Special handling for Submitter to get only dbid
                                                    var changeRequestElement = element.Element(oslcCmNs + "ChangeRequest");
                                                    var dbidElement = changeRequestElement?.Element(cqNs + "dbid");
                                                    return dbidElement != null ? dbidElement.Value : "";
                                                }


                                            }

                                            if (attr.Contains("Attachments") && element != null)
                                            {
                                                // Fetch the URL from rdf:resource attribute
                                                var resourceAttr = element.Attribute(XName.Get("resource", "http://www.w3.org/1999/02/22-rdf-syntax-ns#"));
                                                return resourceAttr != null ? resourceAttr.Value : "";
                                            }

                                            return element?.Value ?? "";
                                        }
                                    )
                               });

                // Create XML for each record type
                XElement recordTypeElement = new XElement(recordType + "s",
                    records.Select(record =>
                    {
                        XElement recordElement = new XElement(recordType,
                            new XAttribute("recordtype", record.RecordType),
                            new XAttribute("dbid", record.Attributes.ContainsKey("dbid") ? record.Attributes["dbid"] : "")
                        );

                        foreach (var attr in record.Attributes)
                        {
                            recordElement.Add(new XElement(attr.Key, attr.Value));
                        }

                        return recordElement;
                    })
                );

                root.Add(recordTypeElement);
            }

            return root;
        }


        public XmlDocument UpdateIMFAfterValidation(XmlDocument XIMF, string recordData, string Exchnageprotocol)
        {
            string RecordID = string.Empty;
            string RecordType = string.Empty;

            if (!string.IsNullOrEmpty(recordData))
            {
                var recordDetails = recordData.Split(':');
                RecordID = recordDetails[0].Trim();
                RecordType = recordDetails[1].Trim();
            }

            XDocument xIssuedoc = null;
            string strHistory = string.Empty;
            string strENS = string.Empty;
            string strESP1 = string.Empty;
            string strExternalConv = string.Empty;

            using (var nodeReader = new XmlNodeReader(XIMF))
            {
                nodeReader.MoveToContent();
                xIssuedoc = XDocument.Load(nodeReader);
            }
            //objlogger.LogInfo("SetDefaultValues : after getting xdoc");

            if (RecordType.ToUpper() == "ISSUE")
            {
                try
                {
                    //ExternalHistory
                    strHistory = xIssuedoc.Root.Element(IMFFileTags.Issue)
                                                             .Element(IMFFileTags.ExternalHistory).Value.ToString().Trim();
                    //ExternalNextState
                    strENS = xIssuedoc.Root.Element(IMFFileTags.Issue)
                                                             .Element(IMFFileTags.ExternalNextState).Value.ToString().Trim();

                    //ExternalConversation
                    strExternalConv = xIssuedoc.Root.Element(IMFFileTags.Issue)
                                                            .Element(IMFFileTags.ExternalConversation).Value.ToString().Trim();

                    //set ESP1 to ENS

                    xIssuedoc.Root.Element(IMFFileTags.Issue)
                                                            .Element(IMFFileTags.ExternalState_Parallel1).Value = strENS;

                    // set External History

                    strHistory = strENS + " - " + GetFormattedDateTime() + " -  ExchangeProtocol:" + Exchnageprotocol + "\n" + strHistory;

                    
                    // set External Conversation
                    strExternalConv = "### " + GetFormattedDateTime() + " " + strENS + " FFM3FE ### \n" + strExternalConv;

                    
                    // set External NextState
                    xIssuedoc.Root.Element(IMFFileTags.Issue).Element(IMFFileTags.ExternalNextState).Value = "";
                    xIssuedoc.Root.Element(IMFFileTags.Issue)
                                                            .Element(IMFFileTags.ExternalConversation).Value = strExternalConv;
                    xIssuedoc.Root.Element(IMFFileTags.Issue)
                                                             .Element(IMFFileTags.ExternalHistory).Value = strHistory;




                    using (var xmlReader = xIssuedoc.CreateReader())
                    {
                        XIMF.Load(xmlReader);
                    }
                }

                catch (Exception ex)
                {

                }
            }


            return XIMF;

        }

        public string ChangeLifeToken4Xprot(string lifeToken4Files, string xprotStatus)
        {
            try
            {
                if (lifeToken4Files.Contains("Failure") && lifeToken4Files.Contains("Success"))
                {
                    xprotStatus = "Incomplete";
                }

                else if (lifeToken4Files.Contains("Failure"))
                {
                    xprotStatus = "Failure";
                }

                else if (lifeToken4Files.Contains("Success"))
                {
                    xprotStatus = "Success";
                }
            }

            catch (Exception ex)
            {

            }

            return xprotStatus;
        }

        /// <summary>
        /// Validates the Rq1 extract data 
        /// </summary>
        /// <param name="xmLDoc"></param>
        /// <param name="recordData"></param>
        /// <param name="objlogger"></param>
        /// <returns></returns>
        public bool ValidateRQ1ExtractFile(XmlDocument RQ1Extract_data, string recordData, AsyncLogger async_objLogger)
        {
            string RecordID = string.Empty;
            string RecordType = string.Empty;

            if (!string.IsNullOrEmpty(recordData))
            {
                var recordDetails = recordData.Split(':');
                RecordID = recordDetails[0].Trim();
                RecordType = recordDetails[1].Trim();
            }

            async_objLogger.LogInfoAsync(RecordID, "BTHelper::ValidateRQ1ExtractFile:Starts");

            try
            {
                var xslt = new XslCompiledTransform();
                xslt.Load(XsltConfig.Audi_Validator);

                using (var writer = new StringWriter())
                using (var reader = new XmlNodeReader(RQ1Extract_data))
                {
                    xslt.Transform(reader, null, writer);
                    string result = writer.ToString();
                    return result.Contains("Validation Successful.");
                }
            }
            catch (XsltException ex)
            {
                Console.WriteLine("Validation Failed: " + ex.Message);
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected Error: " + ex.Message);
                return false;
            }

        }

        public int GetRecordsCount(string LifeToken4Files, Logger objlogger)
        {
            int recordsCount = 0;
            objlogger.LogInfo("GetReordsCount Started : ");

            try
            {
                string[] recordsArray = LifeToken4Files.Split(new string[] { "||||||" }, StringSplitOptions.RemoveEmptyEntries);


                List<string> recordsList = recordsArray.Select(record => record.Trim()).Where(record => !string.IsNullOrEmpty(record)).ToList();


                recordsCount = recordsList.Count;

                objlogger.LogInfo("Total Records Count : " + recordsCount.ToString());

            }

            catch (Exception ex)
            {
                objlogger.LogInfo("Exception Occured in GetRecordsCount method");
                objlogger.LogException(ex);
            }

            objlogger.LogInfo("GetReordsCount Ended : ");
            return recordsCount;
        }


        public int GetBatchCount(int recordsCount, Logger objLogger)
        {
            objLogger.LogInfo("GetBatchCount Started : ");
            int batchCount = 0;

            try
            {
                batchCount = (recordsCount + GlobalConstants.BatchSize - 1) / GlobalConstants.BatchSize;

                objLogger.LogInfo("Batch Size : " + batchCount.ToString());
            }

            catch (Exception ex)
            {
                objLogger.LogInfo("Exception Occured in GetBatchCount method");
                objLogger.LogException(ex);
            }

            return batchCount;
        }

        public  string GetEachRecordFromBatch(string recordNames,  int parallelAction)
        {
           

            string recordName = string.Empty;
           
            string[] recordsArray = recordNames.Split(new string[] { "||||" }, StringSplitOptions.RemoveEmptyEntries);

            int batchSize = recordsArray.Count();

            if(batchSize >= parallelAction)
            {
                recordName = recordsArray[parallelAction - 1].Trim();
            }

            
            return recordName;
            
        }

       public string GetRecordID(string recordNames)
        {
            string recordId = string.Empty;
            try
            {
                string[] record_parts = recordNames.Split(new string[] { "::" }, StringSplitOptions.None);

                if(record_parts[0].ToLower().Contains("issue") || record_parts[0].ToLower().Contains("issuereleasemap"))
                {
                    recordId = record_parts[0].Trim();
                }  
            }
            
            catch(Exception Ex)
            {

            }

            return recordId;
        }
        

        public  string GetRecordNamesFromBatch(string LifeToken4Files, int batchNumber, Logger objLogger)
        {
            objLogger.LogInfo("GetRecordNamesFromBatch Started : ");
            string recordNames = string.Empty;
            
            
            try
            {
                
                string[] recordsArray = LifeToken4Files.Split(new string[] { "||||" }, StringSplitOptions.RemoveEmptyEntries);

                // Calculate the starting index of the batch
                int startIndex = (batchNumber - 1) * GlobalConstants.BatchSize;

                // Ensure the startIndex is within bounds
                if (startIndex >= recordsArray.Length)
                {
                    throw new ArgumentOutOfRangeException("The batch number exceeds the total number of records.");
                }
                else
                {
                    int endIndex = Math.Min(startIndex + GlobalConstants.BatchSize, recordsArray.Length);

                    // Fetch the records in the range of the batch
                    string[] batchRecords = recordsArray.Skip(startIndex).Take(endIndex - startIndex).ToArray();

                    recordNames = string.Join(" |||| ", batchRecords).Trim();

                    objLogger.LogInfo("Record Names : " + recordNames);
                }
 
            }

            catch(Exception ex)
            {
                objLogger.LogException(ex);
            }

            objLogger.LogInfo("GetRecordNamesFromBatch Ended : ");
            return recordNames;
        }



        #endregion

        #region miscellineous

        /// <summary>
        /// Indents the Xml with linebreaks
        /// </summary>
        /// <param name="xmLDoc"></param>
        /// <param name="objlogger"></param>
        /// <returns></returns>
        public XmlDocument PrettyXml(XmlDocument xmLDoc, string recordData, AsyncLogger async_objLogger)
        {
            string RecordID = string.Empty;
            string RecordType = string.Empty;

            if (!string.IsNullOrEmpty(recordData))
            {
                var recordDetails = recordData.Split(':');
                RecordID = recordDetails[0].Trim();
                RecordType = recordDetails[1].Trim();
            }
            try
            {
                async_objLogger.LogInfoAsync(RecordID, "BTHelper::PrettyXml:Starts");

                StringBuilder stringBuilder = new StringBuilder();
                XmlWriterSettings settings = new XmlWriterSettings
                {
                    Indent = true,
                    OmitXmlDeclaration = true
                };
                using (XmlWriter writer = XmlWriter.Create(stringBuilder, settings))
                {
                    xmLDoc.Save(writer);
                }
                xmLDoc.LoadXml(stringBuilder.ToString());
                async_objLogger.LogInfoAsync(RecordID, "BTHelper::PrettyXml:Ends");
                return xmLDoc;
            }
            catch (Exception ex)
            {
                async_objLogger.LogExceptionAsync(RecordID, ex);
                return xmLDoc;
            }
        }

        static XmlDocument FormatXmlDocument(XmlDocument xmlDoc)
        {
            XmlDocument formattedDoc = new XmlDocument();
            using (MemoryStream ms = new MemoryStream())
            {
                XmlWriterSettings settings = new XmlWriterSettings
                {
                    Indent = true,               // Enable indentation
                    IndentChars = "  ",          // Use two spaces for indentation
                    NewLineChars = "\n",         // Use newline for formatting
                    NewLineHandling = NewLineHandling.Replace
                };

                using (XmlWriter writer = XmlWriter.Create(ms, settings))
                {
                    xmlDoc.Save(writer);
                }

                ms.Position = 0; // Reset stream position
                formattedDoc.Load(ms); // Load formatted XML into new XmlDocument
            }
            return formattedDoc;
        }

        static string GetFormattedDateTime()
        {
            return DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
        }


        #endregion



    }

}
