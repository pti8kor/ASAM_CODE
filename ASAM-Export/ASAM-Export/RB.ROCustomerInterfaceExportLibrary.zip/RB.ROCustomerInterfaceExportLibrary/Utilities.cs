﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;


namespace RB.ROCustomerInterfaceExportLibrary
{
    public class Utilities
    {
        /// <summary>
        /// This method will load BizTalk's AppConfig and get the Value for the KEY given
        /// </summary>
        /// <param name="strKey">Key against which the search will be performed</param>
        /// <returns>VALUE for the given KEY</returns>
        public static string LoadItemFromBizTalkAppConfig(string strKey)
        {

            string strValue = ConfigurationManager.AppSettings[strKey];
            return strValue;
        }




    }
}
